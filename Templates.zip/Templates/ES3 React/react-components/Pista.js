'use strict';

class Pista extends React.Component {
    constructor(){
        super();
        this.state = {
        }
    }
    render() {
        
        return (
            
            <div>

            </div>
        );
    }

}