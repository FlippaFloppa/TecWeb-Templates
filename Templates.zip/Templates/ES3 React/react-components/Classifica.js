'use strict';

class Classifica extends React.Component {
    constructor(){
        super();
        this.state = {
        }
    }
    render() {
        
        return (
            
            <div>

            </div>
        );
    }

}